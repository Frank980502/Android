package com.example.ultimetable.bean;

public class Student {
}
